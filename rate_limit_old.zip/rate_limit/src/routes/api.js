const express = require('express');
const router = express.Router();
const rateLimiterMiddleware = require('../middleware/tenant_rate_limit');

router.use(rateLimiterMiddleware);

router.get('/', (req, res) => {
  res.send('Welcome to the API!');

//console.log('Basic');
});

module.exports = router;
