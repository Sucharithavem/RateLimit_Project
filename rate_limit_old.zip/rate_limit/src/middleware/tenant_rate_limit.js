const rateLimit = require('express-rate-limit').default;
const RedisStore = require('rate-limit-redis').default;
const Redis = require('ioredis');

const redisClient = new Redis({
  host: 'localhost',
  port: 6379,
  // You can add more Redis configurations here if needed
});

// Create rate limiters for each tenant type
const rateLimiters = {
  basic: rateLimit({
    store: new RedisStore({
      sendCommand: (...args) => redisClient.call(...args), // Compatibility fix for ioredis
    }),
    windowMs: 1 * 60 * 1000, // 1 minute
    max: 300,
    handler: (req, res) => {
      //console.log('Basic');
      res.status(429).json({ error: 'Too many requests, please try again later.' });
    },
  }),
  professional: rateLimit({
    store: new RedisStore({
      sendCommand: (...args) => redisClient.call(...args), // Compatibility fix for ioredis
    }),
    windowMs: 1 * 60 * 1000, // 1 minute
    max: 400,
    handler: (req, res) => {
      //console.log('Professional');
      res.status(429).json({ error: 'Too many requests, please try again later.' });
    },
  }),
  enterprise: rateLimit({
    store: new RedisStore({
      sendCommand: (...args) => redisClient.call(...args), // Compatibility fix for ioredis
    }),
    windowMs: 1 * 60 * 1000, // 1 minute
    max: 500,
    handler: (req, res) => {
     // console.log('Enterprise');
      res.status(429).json({ error: 'Too many requests, please try again later.' });
    },
  }),
};

const rateLimiterMiddleware = (req, res, next) => {
  const tenantType = req.headers['x-tenant-type'];
  const limiter = rateLimiters[tenantType] || rateLimiters.basic;
  return limiter(req, res, next);
};

module.exports = rateLimiterMiddleware;
