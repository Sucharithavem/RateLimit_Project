const rateLimit = require('express-rate-limit').default;
const RedisStore = require('rate-limit-redis').default;
const Redis = require('ioredis');

const redisClient = new Redis({
  host: 'localhost',
  port: 6379,
});

//Implementing the logic for Basic tenant type
const rateLimiters = {
  basic: rateLimit({
    store: new RedisStore({
      sendCommand: (...args) => redisClient.call(...args), //  fixing Compatibility for ioredis
    }),
    windowMs: 1 * 60 * 1000, // Timestamp difference of 1 minute
    max: 300,
    handler: (req, res) => {
      //console.log('Basic');//Debugging parameter
      res.status(429).json({ error: 'Too many requests, please try again later.' });
    },
  }),
//Implementing the logic for professional tenant type
  professional: rateLimit({
    store: new RedisStore({
      sendCommand: (...args) => redisClient.call(...args), // fixing Compatibility for ioredis
    }),
    windowMs: 1 * 60 * 1000, // Timestamp difference of 1 minute
    max: 400,
    handler: (req, res) => {
      //console.log('Professional');//Debugging parameter
      res.status(429).json({ error: 'Too many requests, please try again later.' });
    },
  }),
//Implementing the logic for Enterprise tenant type
  enterprise: rateLimit({
    store: new RedisStore({
      sendCommand: (...args) => redisClient.call(...args), // fixing Compatibility for ioredis
}),
    windowMs: 1 * 60 * 1000, // Timestamp difference of 1 minute
    max: 500,
    handler: (req, res) => {
     // console.log('Enterprise');//Debugging parameter
      res.status(429).json({ error: 'Too many requests, please try again later.' });
    },
  }),
};

const rateLimiterMiddleware = (req, res, next) => {
  const tenantType = req.headers['x-tenant-type'];
  const limiter = rateLimiters[tenantType] || rateLimiters.basic;
  return limiter(req, res, next);
};

module.exports = rateLimiterMiddleware;
