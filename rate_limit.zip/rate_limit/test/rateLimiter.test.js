const request = require('supertest');//Http requests testing
const express = require('express');
const rateLimiterMiddleware = require('../src/middleware/tenant_rate_limit');//path to the RateLimitMiddleware

const app = express();//Instances of express application
app.use(rateLimiterMiddleware);
app.get('/', (req, res) => res.sendStatus(200));

//  Jest timeout to allow for the delay
jest.setTimeout(70000); // 70 seconds to accommodate the 60-second delay and test execution time

describe('Rate Limiter Middleware', () => {
  beforeEach(() => {
    jest.clearAllMocks(); // Mocks clearing to avoid shared state
  });

  // Added a delay function
  const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  describe('Enterprise Tenant', () => {
    it('should allow requests under the rate limit for enterprise tenant', async () => {
      for (let i = 0; i < 500; i++) {
        const res = await request(app)//verifies if  enterprise tenant can make 500 requests
          .get('/')
          .set('x-tenant-type', 'enterprise');
        expect(res.status).toBe(200);
      }
    });

    it('should block requests over the rate limit for enterprise tenant', async () => {
      await delay(60000); // Wait for 60 seconds
      for (let i = 0; i < 500; i++) {
        await request(app)
          .get('/')
          .set('x-tenant-type', 'enterprise');
      }
      const res = await request(app)
        .get('/')
        .set('x-tenant-type', 'enterprise');
      expect(res.status).toBe(429);
      expect(res.body.error).toBe('Too many requests, please try again later.');
    });
  });

  describe('Professional Tenant', () => {
    it('should allow requests under the rate limit for professional tenant', async () => {
      await delay(60000); // Wait for 60 seconds
      for (let i = 0; i < 400; i++) {
        const res = await request(app)//verifies if  Professional tenant can make 400 requests
          .get('/')
          .set('x-tenant-type', 'professional');
        expect(res.status).toBe(200);
      }
    });

    it('should block requests over the rate limit for professional tenant', async () => {
      await delay(60000); // Wait for 60 seconds
      for (let i = 0; i < 400; i++) {
        await request(app)
          .get('/')
          .set('x-tenant-type', 'professional');
      }
      const res = await request(app)
        .get('/')
        .set('x-tenant-type', 'professional');
      expect(res.status).toBe(429);
      expect(res.body.error).toBe('Too many requests, please try again later.');
    });
  });

  describe('Basic Tenant', () => {
    it('should allow requests under the rate limit for basic tenant', async () => {
      await delay(60000); // Wait for 60 seconds
      for (let i = 0; i < 300; i++) {
        const res = await request(app)//verifies if  Basic tenant can make 3s00 requests
          .get('/')
          .set('x-tenant-type', 'basic');
        expect(res.status).toBe(200);
      }
    });

    it('should block requests over the rate limit for basic tenant', async () => {
      await delay(60000); // Wait for 60 seconds
      for (let i = 0; i < 300; i++) {
        await request(app)
          .get('/')
          .set('x-tenant-type', 'basic');
      }
      const res = await request(app)
        .get('/')
        .set('x-tenant-type', 'basic');
      expect(res.status).toBe(429);
      expect(res.body.error).toBe('Too many requests, please try again later.');
    });
  });
});
